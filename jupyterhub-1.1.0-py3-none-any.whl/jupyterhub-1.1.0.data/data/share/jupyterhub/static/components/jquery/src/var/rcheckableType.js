define( function() {
	"use strict";

	return ( /^(?:checkbox|radio)$/i );
} );
