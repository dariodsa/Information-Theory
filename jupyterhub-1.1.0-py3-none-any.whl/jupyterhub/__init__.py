from ._version import __version__
from ._version import version_info
